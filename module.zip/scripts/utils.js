console.log('sf2e-anachronism-automation | Init file: utils.js');

function getActor(id) {
    let actor;
    if (!id) {
        actor = canvas.tokens.controlled[0]?.actor ?? game.user.character;
        if (!actor) return void ui.notifications.warn("No character assigned and no token selected.");
    } else {
        actor = game.actors.get(id);
        if (!actor) return void console.log("sf2e-anachronism-automation | getActor() did not find id given.)");
    }
    return actor;
}


function actorHasFeat(actor, featName) {
    for (const featGroup of actor.feats.contents) {
        for (const entry of featGroup.feats) {
            if (entry.feat?.name === featName) return true;
        }
    }
    return false;
}


async function applyEffectToAlly(targetToken, effectData) {
    // useful when a player's macro needs to apply an effect to other tokens
    if (targetToken.actor.isOwner) {
        await targetToken.actor.createEmbeddedDocuments("Item", [effectData]);
    } else {
        // Relay through GM account
        console.log('sf2e-anachronism-automation | send to socket')
        game.socket.emit("module.sf2e-anachronism-automation", {
            action: "applyEffect",
            tokenId: targetToken.id,
            effectData: effectData,
        });
    }
}


function getSetting(settingName) {
    if (!settingName) {
        console.log("sf2e-anachronism-automation | no settingName given to getSetting()");
        return;
    }
    return game.settings.get('sf2e-anachronism-automation', settingName);
}


function readableTime(seconds) {
    const days = Math.floor(seconds / (24 * 3600));
    seconds %= 24 * 3600;
    const hours = Math.floor(seconds / 3600);
    seconds %= 3600;
    const minutes = Math.floor(seconds / 60);
    seconds %= 60;

    const parts = [];
    if (days) parts.push(`${days}d`);
    if (hours) parts.push(`${hours}h`);
    if (minutes) parts.push(`${minutes}m`);
    if (seconds || parts.length === 0) parts.push(`${seconds}s`);

    const full = parts.join(" ");
    if (full === "0s") {
        return "no charge"
    } else {
        return full;
    }
}

console.log('sf2e-anachronism-automation | Init successful: utils.js');